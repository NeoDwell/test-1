# hogwatch menubar app

menubar client for [hogwatch](https://github.com/akshayKMR/hogwatch)

######screenshot
<img src="http://i.imgur.com/jZoTllz.jpg" alt="screenshot" height="400px">

see [menubar](https://github.com/maxogden/menubar) Works on Mac OS and some Linuxes (Tested on Xfce4, your mileage may vary -- patches welcome!)

#####requirements:
must have hogwatch installed. if not `sudo pip install hogwatch`

<br>
<br>

## instructions(development)

- run `npm install`
- run `npm run build` to make hogwatch-menubar.app
- run `npm start` to run app from CLI without building hogwatch-menubar.app
